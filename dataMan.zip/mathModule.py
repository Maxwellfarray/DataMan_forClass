# -*- coding: utf-8 -*-
"""
Created on Wed Sep  6 12:36:53 2023

@author: tompkint0208
"""
def doMath(inp):
    holder = float(inp)
    return holder