# -*- coding: utf-8 -*-
"""
Created on Wed Sep  6 12:25:14 2023

@author: tompkint0208
"""
import mathModule as mMod
import inputModule as iMod
gerry = iMod.getInputUnsafe()
gerry = mMod.doMath(gerry)
print (gerry)
